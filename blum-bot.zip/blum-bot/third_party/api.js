const axios = require("axios");
async function getToken() {
  console.log(process.env.QUERY_ID);

  const { data } = await axios({
    url: "https://gateway.blum.codes/v1/auth/provider/PROVIDER_TELEGRAM_MINI_APP",
    method: "POST",
    data: {
      query:
        "query_id=AAHuhy05AwAAAO6HLTng2s20&user=%7B%22id%22%3A7401736174%2C%22first_name%22%3A%22Kang%22%2C%22last_name%22%3A%22Five%20%F0%9F%8D%85%22%2C%22username%22%3A%22bots_five%22%2C%22language_code%22%3A%22en%22%2C%22allows_write_to_pm%22%3Atrue%7D&auth_date=1725546071&hash=1cd236ea722bb1b5197a17c8351957f99d04628f67e91ca6d647c0581b6c3d6a",
      // referralToken: "pgNiFOzMIx", // changeable
      referralToken: "5IbwQZSbUE", // changeable
    },
  });

  return `Bearer ${data.token.access}`;
}
async function getUsername(token) {
  const response = await axios({
    url: "https://gateway.blum.codes/v1/user/me",
    method: "GET",
    headers: { Authorization: token },
  });
  return response.data.username;
}

async function getBalance(token) {
  const response = await axios({
    url: "https://game-domain.blum.codes/api/v1/user/balance",
    method: "GET",
    headers: { Authorization: token },
  });
  return response.data;
}

async function getGameId(token) {
  const { data } = await axios({
    url: "https://game-domain.blum.codes/api/v1/game/play",
    method: "POST",
    headers: { Authorization: token },
    data: null,
  });
  return data;
}

async function claimGamePoints(token, gameId, points) {
  const { data } = await axios({
    url: `https://game-domain.blum.codes/api/v1/game/claim`,
    method: "POST",
    headers: { Authorization: token },
    data: {
      gameId,
      points,
    },
  });
  return data;
}

module.exports = {
  getToken,
  getUsername,
  getBalance,
  getGameId,
  claimGamePoints,
};
